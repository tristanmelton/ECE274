# License

Copyright (c) 2016, Jalali Lab All rights reserved.

PST function is developed in Jalali Lab at University of California, Los Angeles (UCLA). PST is a spin-off from research on the photonic time stretch technique at UCLA. More information about the technique can be found on our group website: http://www.photonics.ucla.edu

The source code provided in the repository is for research purposes only. A license must be obtained from the University of California, Los Angeles for any commercial applications. The software is subject to a pending US patent.

